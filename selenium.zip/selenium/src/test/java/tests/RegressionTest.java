package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Title;

import java.util.concurrent.TimeUnit;

public class RegressionTest {

    @Title("Title check")
    @Description("Checking the title of the loaded page.")
    @Test
    void loginTest() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        driver.get("https://demo.clickdoc.de/cms-de/");
        WebDriverWait title = new WebDriverWait(driver, 15);
        title.until(ExpectedConditions.titleIs("CLICKDOC"));
        driver.findElement(By.xpath("//*[@id=\"menu-item-2004\"]/a")).click();

        WebDriverWait waitForIframe = new WebDriverWait(driver, 15);
        By locIframe = By.id("iframeDialog");
        waitForIframe.until(ExpectedConditions.visibilityOfElementLocated(locIframe));
        driver.switchTo().frame(driver.findElement(locIframe));

        By loginField = By.id("mat-input-0");
        By passwordField = By.id("mat-input-1");
        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginField));
        driver.findElement(loginField).sendKeys("dirk.nonn@cgm.com#1111");
        driver.findElement(passwordField).sendKeys("abcdefg");
        WebElement loginButton = driver.findElement(By.xpath("//div[2]/button"));
        loginButton.click();
        WebDriverWait waitForValidationMessage = new WebDriverWait(driver, 15);
        waitForValidationMessage.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p")));
        driver.findElement(By.xpath("//p")).getText().equals(
                "Bitte überprüfen Sie Ihre E-Mail-Adresse, Passwort und probieren Sie es noch einmal.");
        driver.findElement(loginField).clear();
        driver.findElement(loginField).sendKeys("testmail.com");
        loginButton.click();
        WebDriverWait waitForInvalidEmailMessage = new WebDriverWait(driver, 15);
        waitForInvalidEmailMessage.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p")));
        driver.findElement(By.xpath("//p")).getText().equals(
                "Bitte überprüfen Sie Ihre E-Mail-Adresse, Passwort und probieren Sie es noch einmal.");
        driver.findElement(loginField).clear();

        driver.findElement(loginField).sendKeys("dirk.nonn@cgm.com#1111");
        driver.findElement(passwordField).clear();
        driver.findElement(passwordField).sendKeys("recruitingTest1!");

        loginButton.click();
        WebDriverWait profilePageTitle = new WebDriverWait(driver, 15);
        profilePageTitle.until(ExpectedConditions.titleIs("Mein Profil | CLICKDOC"));

        By profileImage = By.xpath("(//img[@alt='avatar-picture'])[2]");
        WebDriverWait waitForImage = new WebDriverWait(driver, 15);
        Assert.assertTrue(driver.findElement(profileImage).isDisplayed());
        waitForImage.until(ExpectedConditions.visibilityOfElementLocated(profileImage));
        driver.findElement(profileImage).click();
        driver.findElement(By.xpath("//a[2]/div/span[2]")).click();
        driver.quit();
    }


    @Test
    void searchTest() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demo.clickdoc.de/cms-de/");
        WebDriverWait title = new
                WebDriverWait(driver, 15);
        title.until(ExpectedConditions.titleIs("CLICKDOC"));
        driver.findElement(By.linkText("Suchseite")).click();
        driver.findElement(By.xpath("//app-tracking/div/div/div[2]/div[2]")).click();
        driver.findElement(By.id("search-query-typeahead")).clear();
        driver.findElement(By.id("search-query-typeahead")).sendKeys("beate Edel");
        driver.findElement(By.id("search-query-typeahead")).sendKeys(Keys.DOWN);
        driver.findElement(By.xpath("//*[@id=\"search\"]/div/div[2]/div[2]/div[1]/app-filter/div/div/div[2]/div[6]/div/button")).click();

        By searchResult = By.xpath("//*[@id=\"search\"]/div/div[3]/div/div/app-physician-card[1]/div/div[1]/div[2]");
        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchResult));
        driver.findElement(searchResult).getText().contains("beate");
        WebElement pinCodeSearchField = driver.findElement(By.id("search-location-typeahead"));
        pinCodeSearchField.clear();
        pinCodeSearchField.sendKeys("56567");
        By pinCodeDropdown = By.xpath("//*[@id=\"search\"]/div/div[2]/div[2]/div[1]/app-filter/div/div/div[2]/div[2]/div/div/div[1]/typeahead-container");
        WebDriverWait waitForPinSearchDropdown = new WebDriverWait(driver, 15);
        waitForPinSearchDropdown.until(ExpectedConditions.visibilityOfElementLocated(pinCodeDropdown));
        //driver.findElement(pinCodeDropdown).sendKeys(Keys.DOWN);
        //driver.findElement(pinCodeDropdown).sendKeys(Keys.RETURN);
        Assert.assertTrue(driver.findElement(pinCodeDropdown).isSelected());
        driver.quit();
    }


}
