package tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class BaseTest {
  public WebDriver driver;
  public ExtentHtmlReporter htmlReporter;
  public ExtentReports extent;
  public ExtentTest test;
  public static ThreadLocal<WebDriver> tdriver = new ThreadLocal<WebDriver>();

  public WebDriver initialize_driver() {

    WebDriverManager.chromedriver().setup();
    driver = new ChromeDriver();
    driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
    driver.manage().window().maximize();
    tdriver.set(driver);
    return getDriver();
  }

  public static synchronized WebDriver getDriver() {
    return tdriver.get();
  }
  @BeforeTest
  public void setExtent() {
    // specify location of the report
    htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/extent/myReport.html");

    htmlReporter.config().setDocumentTitle("Automation Report"); // Tile of report
    htmlReporter.config().setReportName("Functional Testing"); // Name of the report
    htmlReporter.config().setTheme(Theme.DARK);

    extent = new ExtentReports();
    extent.attachReporter(htmlReporter);

    // Passing General information
    extent.setSystemInfo("Host name", "localhost");
    extent.setSystemInfo("Environemnt", "QA");
    extent.setSystemInfo("user", "Soumya Xavier");
  }

  @AfterTest
  public void endReport() {
    extent.flush();
  }

  @AfterMethod
  public void tearDown(ITestResult result) throws IOException {
    if (result.getStatus() == ITestResult.FAILURE) {
      test.log(Status.FAIL, "TEST CASE FAILED IS " + result.getName()); // to add name in extent report
      test.log(Status.FAIL, "TEST CASE FAILED IS " + result.getThrowable()); // to add error/exception in extent report
      String screenshotPath = getScreenshot(driver, result.getName());
      test.addScreenCaptureFromPath(screenshotPath);// adding screen shot
    } else if (result.getStatus() == ITestResult.SKIP) {
      test.log(Status.SKIP, "Test Case SKIPPED IS " + result.getName());
    } else if (result.getStatus() == ITestResult.SUCCESS) {
      test.log(Status.PASS, "Test Case PASSED IS " + result.getName());
    }
    driver.quit();
  }

  public static String getScreenshot(WebDriver driver, String screenshotName) throws IOException {
    String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
    TakesScreenshot ts = (TakesScreenshot) driver;
    File source = ts.getScreenshotAs(OutputType.FILE);

    // after execution, you could see a folder "FailedTestsScreenshots" under src folder
    String destination = System.getProperty("user.dir") + "/extent/" + screenshotName + dateName + ".png";
    File finalDestination = new File(destination);
    FileUtils.copyFile(source, finalDestination);
    return destination;
  }
}



  /*@BeforeMethod
  public void setup() {
    System.setProperty("webdriver.chrome.driver", "C://Drivers/chromedriver_win32/chromedriver.exe");
    driver = new ChromeDriver();
    driver.manage().window().maximize();
    driver.get("http://demo.nopcommerce.com/");
  }*/
//
//    @BeforeEach
//    public void SetExtent() {
//        extent = new ExtentReports(System.getProperty("user.dir") + "/Extent/ExtentReport.html", true);
//        extent.addSystemInfo("Author", "Soumya Xavier");
//        extent.addSystemInfo("User Name", System.getProperty("user.name"));
//        extent.addSystemInfo("OS Name", os);
//        extent.addSystemInfo("OS Version", System.getProperty("os.version"));
//        extent.addSystemInfo("Java Version", System.getProperty("java.version"));
//        extent.addSystemInfo("Date/Time", new Date().toString());
//    }
//

//    public static WebDriver driver;
//    public static WebDriverWait wait;
//    static Properties prop;
//    public ExtentReports extent;
//    public ExtentTest extentTest;
//
//
//    @BeforeMethod
//    public void setUp(String browser) {
//
//        log.info("Launching Browser");
//
//        if (browser.equalsIgnoreCase("firefox") && os.equals("windows 10")) {
//            System.setProperty("webdriver.gecko.driver", "src/main/resources/drivers/geckodriver.exe");
//            driver = new FirefoxDriver();
//        } else if (browser.equalsIgnoreCase("chrome") && os.equals("windows 10")) {
//            System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver.exe");
//            driver = new ChromeDriver();
//        } else if (browser.equalsIgnoreCase("firefox") && os.contains("linux") && dataModel.contains("64")) {
//            System.setProperty("webdriver.gecko.driver", "src/main/resources/drivers/geckodriver_linux64");
//            driver = new FirefoxDriver();
//        } else if (browser.equalsIgnoreCase("firefox") && os.contains("linux") && dataModel.contains("32")) {
//            System.setProperty("webdriver.gecko.driver", "src/main/resources/drivers/geckodriver_linux32");
//            driver = new FirefoxDriver();
//        } else if (browser.equalsIgnoreCase("firefox") && os.contains("mac")) {
//            System.setProperty("webdriver.gecko.driver", "src/main/resources/drivers/geckodriver_mac");
//            driver = new FirefoxDriver();
//        } else if (browser.equalsIgnoreCase("chrome") && os.contains("linux")) {
//            System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver_linux");
//            driver = new ChromeDriver();
//        } else if (browser.equalsIgnoreCase("chrome") && os.contains("mac")) {
//            System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver_mac");
//            driver = new ChromeDriver();
//        }
//
//        driver.manage().deleteAllCookies();
//        driver.manage().window().maximize();
//        wait = new WebDriverWait(driver, 10, 50);
//        driver.manage().timeouts().pageLoadTimeout(Utils.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
//        driver.manage().timeouts().implicitlyWait(Utils.IMPLICIT_WAIT, TimeUnit.SECONDS);
//        driver.get(prop.getProperty("url"));
//        log.info("Launching Application in Chrome Browser");
//    }
//
//
//    @AfterMethod
//    public void tearDown(ITestResult result) throws IOException {
//        if (result.getStatus() == ITestResult.FAILURE) {
//            extentTest.log(LogStatus.FAIL, "Test Case Failed is: " + result.getName());
//            extentTest.log(LogStatus.FAIL, "Test Case Failed is: " + result.getThrowable());
//
//            String screenshotPath = TestBase.getScreenshot(driver, result.getName());
//            extentTest.log(LogStatus.FAIL, extentTest.addScreenCapture(screenshotPath));
//
//        } else if (result.getStatus() == ITestResult.SKIP) {
//            extentTest.log(LogStatus.SKIP, "Test Case Skipped is: " + result.getName());
//        } else if (result.getStatus() == ITestResult.SUCCESS) {
//            extentTest.log(LogStatus.PASS, "Test Case Passed is: " + result.getName());
//            extentTest.log(LogStatus.INFO, "Ending the Execution of the method: " + "'" + result.getName() + "'");
//        }
//        extent.endTest(extentTest);
//        // driver.close();
//        driver.quit();
//    }
//
//    public static String getScreenshot(WebDriver driver, String screenshotName) throws IOException {
//        String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
//        TakesScreenshot ts = (TakesScreenshot) driver;
//        File source = ts.getScreenshotAs(OutputType.FILE);
//        String destination = System.getProperty("user.dir") + "Extent/" + screenshotName + dateName + ".png";
//        File finalDestination = new File(destination);
//        FileUtils.copyFile(source, finalDestination);
//        return destination;
//    }
//
//
//    @BeforeTest
//    public void SetExtent() {
//        extent = new ExtentReports(System.getProperty("user.dir") + "Extent/ExtentReport.html", true);
//        extent.addSystemInfo("Author", "Priyatham Bolli");
//        extent.addSystemInfo("User Name", System.getProperty("user.name"));
//        String os = System.getProperty("os.name").toLowerCase();
//        extent.addSystemInfo("OS Name", os);
//        extent.addSystemInfo("OS Version", System.getProperty("os.version"));
//        extent.addSystemInfo("Java Version", System.getProperty("java.version"));
//        extent.addSystemInfo("Date/Time", new Date().toString());
//    }
//
//    @AfterTest
//    public void endReport() {
//        extent.flush();
//        extent.close();
//    }

